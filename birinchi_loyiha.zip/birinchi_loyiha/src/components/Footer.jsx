import '../assets/style/footer.css'
import '../assets/style/style.css'
function Footer() {
	return (
		<div className='footer'>
			<div className='container' id='containers'>
				<h3>Copyright 2021 News Portal</h3>
			</div>
		</div>
	)
}

export default Footer
